#!/usr/bin/env python3
import rospy
import actionlib
from actionlib_tutorials.msg import FibonacciAction, FibonacciGoal

def fibonacci_client():
    client = actionlib.SimpleActionClient('fibonacci', FibonacciAction)
    client.wait_for_server()

    goal = FibonacciGoal(order=20)
    client.send_goal(goal)

    client.wait_for_result()
    return client.get_result()

if __name__ == '__main__':
    try:
        rospy.init_node('fibonacci_client')
        result = fibonacci_client()
        print("Result:", result.sequence)
    except rospy.ROSInterruptException:
        print("Program interrupted before completion")
